MASA Clinical Quick - GitHub Pages用

配置例:
repo-root/
  clinical/
    index.html
    manifest.webmanifest
    sw.js
    icon-192.png
    icon-512.png
    apple-touch-icon.png

GitHub Pagesがリポジトリ直下を公開している場合:
1. この clinical フォルダをリポジトリへ追加
2. commit / push
3. https://<ユーザー名>.github.io/<リポジトリ名>/clinical/ をiPhoneのSafariで開く
4. 共有 → ホーム画面に追加
5. 「MASA Clinical」として起動

既存MASA OSのHOMEからリンクする場合:
<a href="./clinical/">CLINICAL</a>
（HOMEのindex.htmlとclinicalフォルダが同じ階層の場合）

注意:
- 症例名に患者氏名、生年月日、電話番号などの個人情報を入れない。
- 入力内容はブラウザのlocalStorageに端末内保存される。
